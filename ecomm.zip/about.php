<?php include 'include/header.php'; ?>
    <section id="page-header" class="about-header">
        <h2>#KnowUs</h2>
        <p>You can know us by subscribing! </p>
    </section>

    <section id="about-head" class="section-p1">
        <img src="img/about/a6.jpg" alt="about page">
        <div>
            <h2>Who We Are? </h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sapiente. Dolorum neque sed iusto dolore
                impedit fugit consectetur repellat similique sunt ipsum asperiores minima, dignissimos ex obcaecati
                doloremque temporibus amet, voluptatem ea, hic maiores.</p>
            <br> <br>
            <marquee  loop="-1" scrollamount="5" width="100%">Create Stunning images with as much as or as
                little control or as you
                like thanks to a choice of basic and creative modes.</marquee>
        </div>
    </section>

    <section id="about-app" class="section-p1">
        <h1>DownLoad our <a href="#">App</a></h1>
        <div class="video">
            <video src="img/about/1.mp4" autoplay muted loop></video>
        </div>

    </section>

    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="img/features/f1.png" alt="feature">
            <h6>Free Shipping</h6>
        </div>

        <div class="fe-box">
            <img src="img/features/f2.png" alt="feature">
            <h6>Online Order</h6>
        </div>

        <div class="fe-box">
            <img src="img/features/f3.png" alt="feature">
            <h6>Save Money</h6>
        </div>

        <div class="fe-box">
            <img src="img/features/f4.png" alt="feature">
            <h6>Promotions</h6>
        </div>

        <div class="fe-box">
            <img src="img/features/f5.png" alt="feature">
            <h6>Happy Sell</h6>
        </div>

        <div class="fe-box">
            <img src="img/features/f6.png" alt="feature">
            <h6>24/7 Support</h6>
        </div>
    </section>


    <?php include 'include/footer.php'; ?>