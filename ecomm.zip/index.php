<?php
require_once __DIR__ . "/home.php";